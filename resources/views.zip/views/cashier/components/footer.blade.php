<footer class="w-full border-t border-default-200 bg-white p-4 dark:bg-default-50 print:hidden">
    <div class="flex flex-wrap items-center justify-between gap-2">
        <p class="text-center font-semibold text-default-600">
            <script>
                document.write(new Date().getFullYear());
            </script>
            Designed & Crafted With 💚 by
            <a class="text-primary" target="_blank">CodeXpress Technologies</a>
        </p>
    </div>
</footer>
