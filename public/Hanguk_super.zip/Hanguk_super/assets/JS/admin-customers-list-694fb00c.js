import{f as a}from"./index-a4e39586.js";a("#datepicker-basic",{defaultDate:new Date});
