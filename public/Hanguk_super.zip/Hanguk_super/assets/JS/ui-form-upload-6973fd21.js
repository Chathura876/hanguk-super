import"./theme-9c065fc6.js";import{$ as e}from"./dropzone-f13a1568.js";document.addEventListener("DOMContentLoaded",()=>{new e("#my-dropzone",{})});
